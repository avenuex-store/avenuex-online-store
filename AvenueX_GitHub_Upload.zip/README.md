# Avenuex.Online-Store — source upload (private repository)

This package contains the V4 browser prototype source files only. The original Excel workbook and extracted business/customer transaction data have intentionally been excluded. A blank demo seed file is included so the prototype can open without exposing real records.

## Important status
- This is **not yet a cloud-connected production store**.
- `app.js` and `storefront.js` still use browser `localStorage`; customer orders will not sync to the owner's other devices.
- No Supabase project, authentication, database policies, payment gateway, or hosting is configured here.
- Do not enter real customer, financial, or payment data into this prototype.
- Keep this GitHub repository **Private**. Never upload database passwords, API secret/service-role keys, real customer exports, or the original workbook.

## Local preview
On Windows, run `Start_Local_Demo_Windows.bat`. The included seed file is intentionally empty.

## Next production tasks
1. Design the cloud database and secure owner authentication.
2. Add server-side authorization and row-level security before exposing any private data.
3. Replace localStorage reads/writes in both app pages with authenticated cloud API calls.
4. Build public catalog/order endpoints with server-side stock validation and order creation.
5. Test owner-only admin access and customer-only storefront access.
6. Deploy only after security and end-to-end tests pass.

Do not enable public hosting of this prototype as a live store until these tasks are complete.
